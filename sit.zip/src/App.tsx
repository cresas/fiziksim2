import FreeFallSimulation from './FreeFallSimulation';

function App() {
  return <FreeFallSimulation />;
}

export default App;